package RLL_240Testing_PhpTravels_Hotels_StepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchHotels_StepDefinition {
	
	
	@Given("the user is on the PHP Travels hotels page")
	public void the_user_is_on_the_php_travels_hotels_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("the user enters {string} as the location")
	public void the_user_enters_as_the_location(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Check-In Date {string}")
	public void selects_check_in_date(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Check-Out Date {string}")
	public void selects_check_out_date(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Number of Rooms {string}")
	public void selects_number_of_rooms(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Number of Adults {string}")
	public void selects_number_of_adults(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Number of Children {string}")
	public void selects_number_of_children(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Child Age {string}")
	public void selects_child_age(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("clicks on Nationality")
	public void clicks_on_nationality() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("selects Nationality {string}")
	public void selects_nationality(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("clicks the search button")
	public void clicks_the_search_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("the user should see {string} in the search box")
	public void the_user_should_see_in_the_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("the user should see \"\"Please select an item in the list\"\" in the search box")
	public void the_user_should_see_please_select_an_item_in_the_list_in_the_search_box() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("the user clicks on Star Rating")
	public void the_user_clicks_on_star_rating() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("clicks on Price Range")
	public void clicks_on_price_range() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("clicks on Price Sort by")
	public void clicks_on_price_sort_by() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("the user should see hotel details by valid filters")
	public void the_user_should_see_hotel_details_by_valid_filters() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("the user should see all hotel details by default values")
	public void the_user_should_see_all_hotel_details_by_default_values() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	

}
